module shopTest {
    requires shop;
}